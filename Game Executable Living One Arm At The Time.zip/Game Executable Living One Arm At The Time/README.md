# LivingOneArmAtTheTime
 Prototype project for STGE Gender Issues

//////////////////////////////////////////
HOW TO PLAY:

[SPACE] to start the game
[ESC] to Quit/Pause the game
[W],[A],[S],[D] to move around the scene

Mouse panning to look around and hover over the objects
Right mouse click to pick up objects
Left mouse click to drop the objects

//////////////////////////////////////////
GOAL OF THE GAME:
Collect all of the items from the list into the 
middle of the living room (marke dwith green tape)
Use different characters to reach higher spaces

//////////////////////////////////////////